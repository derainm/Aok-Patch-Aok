﻿// Decompiled with JetBrains decompiler
// Type: Extension.Methods
// Assembly: SLX Studio, Version=1.4.1.0, Culture=neutral, PublicKeyToken=null
// MVID: B1DE9AF1-FC33-4D79-BEAE-2919C4AAE382
// Assembly location: C:\Users\Beleive\Desktop\SLX Studio.exe


using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Windows.Forms.Layout;

namespace Extension
{
  public static class Methods
  {
    public static void DPIAwareCompensation(this Form form)
    {
      int num1 = (int) (8.0 * (double) Global.dpi);
      int num2 = (int) (24.0 * (double) Global.dpi);
      double num3 = (double) (form.Width - num1) / (double) form.Width;
      double num4 = (double) (form.Height - num2) / (double) form.Height;
      foreach (Control control1 in (ArrangedElementCollection) form.Controls)
      {
        AnchorStyles anchor = control1.Anchor;
        control1.Anchor = AnchorStyles.None;
        Control control2 = control1;
        control2.Size = new Size((int) ((double) control2.Width * num3), (int) ((double) control1.Height * num4));
        Control control3 = control1;
        Point location = control3.Location;
        int x = (int) ((double) location.X * num3);
        location = control1.Location;
        int y = (int) ((double) location.Y * num4);
        control3.Location = new Point(x, y);
        control1.Anchor = anchor;
      }
    }

    public static string GetSubstring(this string parent, int offset, int length)
    {
      if (parent.Length >= length)
        return parent.Substring(offset, length);
      return parent.Substring(offset, parent.Length - offset);
    }

    public static string[] Split(this string s, string separator)
    {
      return s.Split(new string[1]{ separator }, StringSplitOptions.None);
    }

    public static string TrimEnd(this string parent, string trim)
    {
      string str = parent;
      if (str.Substring(str.Length - trim.Length) == trim)
        return parent.Substring(0, parent.Length - trim.Length);
      return parent;
    }

    public static string TrimEnd(this string parent, string[] trim)
    {
      foreach (string str1 in trim)
      {
        string str2 = parent;
        if (str2.Substring(str2.Length - str1.Length) == str1)
          return parent.Substring(0, parent.Length - str1.Length);
      }
      return parent;
    }

    public static string GetItemName(
      string itemName,
      bool removeEndHyphen = true,
      bool removeEndUnderscore = true,
      bool removeEndPeriod = true)
    {
      string s = Regex.Match(itemName, "\\d+$").Value;
      int result;
      int.TryParse(s, out result);
      int length = s.Length;
      if (result.ToString().Substring(0, 1) == ".")
        --length;
      itemName = itemName.Substring(0, itemName.Length - length);
      if (removeEndHyphen)
        itemName = itemName.TrimEnd('-');
      if (removeEndUnderscore)
        itemName = itemName.TrimEnd('_');
      if (removeEndPeriod)
        itemName = itemName.TrimEnd('.');
      return itemName;
    }

    public static string AddItemPadding(string itemName, int paddingSize, int value)
    {
      string str = value.ToString();
      for (int length = str.Length; length < paddingSize; ++length)
        str = "0" + str;
      itemName += str;
      return itemName;
    }

    public static string GetPadding(int paddingSize, int value)
    {
      string str = value.ToString();
      for (int length = str.Length; length < paddingSize; ++length)
        str = "0" + str;
      return str;
    }

    public static string GetPaddingFromString(this string itemName)
    {
      return Regex.Match(itemName, "\\d+$").Value;
    }

    public static string ResetItemPadding(string itemName, int paddingSize)
    {
      string s = Regex.Match(itemName, "\\d+$").Value;
      int result;
      int num = int.TryParse(s, out result) ? 1 : 0;
      int length1 = s.Length;
      if (num == 0 || length1 == paddingSize)
        return itemName;
      string str = result.ToString();
      for (int length2 = str.Length; length2 < paddingSize; ++length2)
        str = "0" + str;
      itemName = Methods.GetItemName(itemName, false, false, false);
      itemName += str;
      return itemName;
    }

    public static string RemoveNonDigits(this string value)
    {
      return Regex.Replace(value, "[^0-9]", string.Empty);
    }

    public static string GetDirectory(this string value)
    {
      return Path.GetDirectoryName(value) + "\\";
    }

    public static string GetFileName(this string value)
    {
      return Path.GetFileName(value);
    }

    public static string GetFileNameWithoutExtension(this string value)
    {
      return Path.GetFileNameWithoutExtension(value);
    }

    public static string GetSLXStudioVersion(int length = -1)
    {
      if (length == 0)
        return (string) null;
      string str1 = Assembly.GetExecutingAssembly().GetName().Version.ToString().Substring(0, 5);
      string str2 = str1.Substring(4);
      string str3 = str1.Substring(0, 3);
      if (length > 0)
      {
        str3 += str2;
        if (length < str3.Length)
          str3 = str3.Substring(0, length);
        else if (length > str3.Length)
        {
          while (str3.Length < length)
            str3 += " ";
        }
      }
      else if (!(str2 == "0"))
        str3 = str3 + "." + str2;
      return str3;
    }

    public static void ShiftList(List<string> list, int index, int direction)
    {
      if (index >= list.Count)
        return;
      if (direction < 0)
      {
        string str = list[index];
        list.RemoveAt(index);
        list.Insert(index + direction, str);
      }
      if (direction <= 0)
        return;
      string str1 = list[index];
      list.RemoveAt(index);
      list.Insert(index + direction, str1);
    }

    public static void ShiftList(List<object> list, int index, int direction)
    {
      if (index >= list.Count)
        return;
      if (direction < 0)
      {
        object obj = list[index];
        list.RemoveAt(index);
        list.Insert(index + direction, obj);
      }
      if (direction <= 0)
        return;
      object obj1 = list[index];
      list.RemoveAt(index);
      list.Insert(index + direction, obj1);
    }

    public static void ShiftList(List<bool> list, int index, int direction)
    {
      if (index >= list.Count)
        return;
      if (direction < 0)
      {
        bool flag = list[index];
        list.RemoveAt(index);
        list.Insert(index + direction, flag);
      }
      if (direction <= 0)
        return;
      bool flag1 = list[index];
      list.RemoveAt(index);
      list.Insert(index + direction, flag1);
    }

    public static void ShiftList(List<int> list, int index, int direction)
    {
      if (index >= list.Count)
        return;
      if (direction < 0)
      {
        int num = list[index];
        list.RemoveAt(index);
        list.Insert(index + direction, num);
      }
      if (direction <= 0)
        return;
      int num1 = list[index];
      list.RemoveAt(index);
      list.Insert(index + direction, num1);
    }

    public static List<Process> GetProcessesAssociatedToFile(string file)
    {
      return ((IEnumerable<Process>) Process.GetProcesses()).Where<Process>((Func<Process, bool>) (x =>
      {
        if (!x.HasExited)
          return x.Modules.Cast<ProcessModule>().ToList<ProcessModule>().Exists((Predicate<ProcessModule>) (y => y.FileName.ToLowerInvariant() == file.ToLowerInvariant()));
        return false;
      })).ToList<Process>();
    }

    public static string GetStringFromClass(System.Type type, string varName)
    {
      return (string) type.GetField(varName, BindingFlags.Static | BindingFlags.Public).GetValue((object) null);
    }

    public static string[] GetStringArrayFromClass(System.Type type, string varName)
    {
      return (string[]) type.GetField(varName, BindingFlags.Static | BindingFlags.Public).GetValue((object) null);
    }

    public static string ToBinaryString(this int value)
    {
      return Convert.ToString(value, 2);
    }

    public static string ToHexString(this byte[] array)
    {
      return BitConverter.ToString(array).Replace("-", "");
    }

    public static string ToHexString(this Color color, bool alpha = true)
    {
      if (alpha)
        return color.A.ToString("X2") + color.R.ToString("X2") + color.G.ToString("X2") + color.B.ToString("X2");
      return color.R.ToString("X2") + color.G.ToString("X2") + color.B.ToString("X2");
    }

    public static bool IsValidFilename(this string fileName)
    {
      return !new Regex("[" + Regex.Escape(new string(Path.GetInvalidPathChars())) + "]").IsMatch(fileName);
    }

    public static int ToInt(this string value)
    {
      try
      {
        return Convert.ToInt32(value);
      }
      catch
      {
        return 0;
      }
    }

    public static int ToInt(this double value)
    {
      try
      {
        return Convert.ToInt32(value);
      }
      catch
      {
        return 0;
      }
    }

    public static int ToInt(this Decimal value)
    {
      try
      {
        return Convert.ToInt32(value);
      }
      catch
      {
        return 0;
      }
    }

    public static int ToInt(this float value)
    {
      try
      {
        return Convert.ToInt32(Math.Round((double) value));
      }
      catch
      {
        return 0;
      }
    }

    public static int ToInt(this byte value)
    {
      try
      {
        return Convert.ToInt32(value);
      }
      catch
      {
        return 0;
      }
    }

    public static int RoundUpToEven(this int value)
    {
      if (value.IsEven())
        ++value;
      return value;
    }

    public static int RoundUpToNearestDivibleBy(this int value, int divisible)
    {
      return (int) Math.Ceiling((double) value / (double) divisible) * divisible;
    }

    public static int ConvertToIntOrZero(this string value)
    {
      try
      {
        if (value == null || value.Trim() == string.Empty)
          return 0;
        return int.Parse(value.Split("_")[0]);
      }
      catch (Exception ex)
      {
        return 0;
      }
    }

    public static int GetBrightnessFactor(this Color color)
    {
      return ((double) (0 + ((int) color.R + (int) color.G + (int) color.B)) / 3.0).ToInt();
    }

    public static int GetBrightnessFactor(this List<Color> colors)
    {
      int num = 0;
      foreach (Color color in colors)
        num += (int) color.R + (int) color.G + (int) color.B;
      return ((double) num / (double) colors.Count / 3.0).ToInt();
    }

    public static int GetMaxRGBValue(this Color color)
    {
      int num = (int) color.R;
      if (num < (int) color.G)
        num = (int) color.G;
      if (num < (int) color.B)
        num = (int) color.B;
      return num;
    }

    public static double GetColorMultiplier(this Color color, Color mod)
    {
      return (double) (((int) mod.R + (int) mod.G + (int) mod.B) / ((int) color.R + (int) color.G + (int) color.B));
    }

    public static int GetVersionNumber(string version)
    {
      int num = 0;
      version = version.Replace(".", "");
      if (version.IsNumeric())
        num = version.ToInt();
      return num;
    }

    public static int GetIntFromClass(System.Type type, string varName)
    {
      return (int) type.GetField(varName, BindingFlags.Static | BindingFlags.Public).GetValue((object) null);
    }

    public static int[] GetIntArrayFromClass(System.Type type, string varName)
    {
      return (int[]) type.GetField(varName, BindingFlags.Static | BindingFlags.Public).GetValue((object) null);
    }

    public static int GetFileSize(string path)
    {
      if (File.Exists(path))
        return Convert.ToInt32(new FileInfo(path).Length);
      return 0;
    }

    public static int GetBits(this byte b, int startIndex, int endIndex)
    {
      if (startIndex > 7 || startIndex < 0 || (endIndex > 7 || endIndex < 0) || endIndex < startIndex)
        return 0;
      int num = (int) Math.Pow(2.0, (double) (endIndex - startIndex + 1)) - 1;
      return (int) b >> startIndex & num;
    }

    public static int MaxDirections(int numFrames, int controlMaximum)
    {
      int num1 = Global.graphicFiles.Count;
      int num2 = 2;
      while (num1 > controlMaximum)
      {
        num1 = Global.graphicFiles.Count / num2;
        ++num2;
      }
      return num1;
    }

    public static int GetRadius(this Bitmap source)
    {
      return source.Width / 2 + source.Height / 2 / 2;
    }

    public static int GetLeftMargin(Bitmap source, Color[] pixelColors, bool invertColors = false)
    {
      for (int x = 0; x < source.Width; ++x)
      {
        for (int y = 0; y < source.Height; ++y)
        {
          Color pixel = source.GetPixel(x, y);
          if (((IEnumerable<Color>) pixelColors).Contains<Color>(pixel) == !invertColors)
            return x;
        }
      }
      return source.Width;
    }

    public static int GetRightMargin(Bitmap source, Color[] pixelColors, bool invertColors = false)
    {
      for (int x = source.Width - 1; x >= 0; --x)
      {
        for (int y = 0; y < source.Height; ++y)
        {
          Color pixel = source.GetPixel(x, y);
          if (((IEnumerable<Color>) pixelColors).Contains<Color>(pixel) == !invertColors)
            return source.Width - (x + 1);
        }
      }
      return source.Width;
    }

    public static int GetTopMargin(Bitmap source, Color[] pixelColors, bool invertColors = false)
    {
      for (int y = 0; y < source.Height; ++y)
      {
        for (int x = 0; x < source.Width; ++x)
        {
          Color pixel = source.GetPixel(x, y);
          if (((IEnumerable<Color>) pixelColors).Contains<Color>(pixel) == !invertColors)
            return y;
        }
      }
      return source.Height;
    }

    public static int GetBottomMargin(Bitmap dataFrame, Color[] pixelColors, bool invertColors = false)
    {
      for (int y = dataFrame.Height - 1; y >= 0; --y)
      {
        for (int x = 0; x < dataFrame.Width; ++x)
        {
          Color pixel = dataFrame.GetPixel(x, y);
          if (((IEnumerable<Color>) pixelColors).Contains<Color>(pixel) == !invertColors)
            return dataFrame.Height - (y + 1);
        }
      }
      return dataFrame.Height;
    }

    public static bool IsNull(this string s)
    {
      return string.IsNullOrEmpty(s) || string.IsNullOrWhiteSpace(s);
    }

    public static bool IsNumeric(this string value)
    {
      int result;
      return int.TryParse(value, out result);
    }

    public static bool IsHexString(this string hex)
    {
      return Regex.IsMatch(hex, "\\A\\b[0-9a-fA-F]+\\b\\Z");
    }

    public static bool IsUpper(this string value)
    {
      for (int index = 0; index < value.Length; ++index)
      {
        if (!char.IsUpper(value[index]))
          return false;
      }
      return true;
    }

    public static bool IsInterger(this double value)
    {
      return value % 1.0 == 0.0;
    }

    public static bool IsEven(this int value)
    {
      if (value == 0)
        return true;
      return ((double) (value / 2)).IsInterger();
    }

    public static bool IsOdd(this int value)
    {
      if (value == 0)
        return false;
      return !((double) (value / 2)).IsInterger();
    }

    public static bool IsValidImage(string fileName, bool message = true)
    {
      try
      {
        Bitmap bitmap;
        using (FileStream fileStream = new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
        {
          bitmap = new Bitmap(Image.FromStream((Stream) fileStream));
          fileStream.Flush();
          fileStream.Close();
          fileStream.Dispose();
        }
        bitmap.Dispose();
      }
      catch
      {
        if (message)
        {
          if (MessageBox.Show("Unable to read " + Path.GetFileName(fileName) + ". It may be corrupted, damaged, or an invalid " + Path.GetExtension(fileName).ToUpper() + " file.", "Error", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
            Global.cancelProgress = true;
        }
        return false;
      }
      return true;
    }

    public static bool IsFileLocked(string file)
    {
      if (!File.Exists(file))
        return false;
      FileStream fileStream = (FileStream) null;
      try
      {
        fileStream = File.Open(file, FileMode.Open, FileAccess.Read, FileShare.None);
      }
      catch (IOException ex)
      {
        return true;
      }
      finally
      {
        fileStream?.Close();
      }
      return false;
    }

    public static bool IsTransparent(this Bitmap source)
    {
      if (source.PixelFormat != PixelFormat.Format32bppArgb && source.PixelFormat != PixelFormat.Format32bppPArgb && (source.PixelFormat != PixelFormat.Format64bppArgb && source.PixelFormat != PixelFormat.Format64bppPArgb))
        return false;
      DirectBitmap directBitmap = new DirectBitmap(source);
      for (int y = 0; y < directBitmap.Height; ++y)
      {
        for (int x = 0; x < directBitmap.Width; ++x)
        {
          int a = (int) directBitmap.GetPixel(x, y).A;
          if (a >= 0 && a < (int) byte.MaxValue)
            return true;
        }
      }
      return false;
    }

    public static bool IsTransparent(this Image source)
    {
      if (source.PixelFormat != PixelFormat.Format32bppArgb && source.PixelFormat != PixelFormat.Format32bppPArgb && (source.PixelFormat != PixelFormat.Format64bppArgb && source.PixelFormat != PixelFormat.Format64bppPArgb))
        return false;
      DirectBitmap directBitmap = new DirectBitmap(source);
      for (int y = 0; y < directBitmap.Height; ++y)
      {
        for (int x = 0; x < directBitmap.Width; ++x)
        {
          int a = (int) directBitmap.GetPixel(x, y).A;
          if (a >= 0 && a < (int) byte.MaxValue)
            return true;
        }
      }
      return false;
    }

    public static bool IsAllEqual(this int[] array)
    {
      bool flag = true;
      for (int index = 0; index < array.Length; index = index + 1 + 1)
      {
        if (index > 0 && array[index] != array[index - 1])
          flag = false;
      }
      return flag;
    }

    public static bool IsAllEqual(this List<int> array)
    {
      bool flag = true;
      for (int index = 0; index < array.Count; index = index + 1 + 1)
      {
        if (index > 0 && array[index] != array[index - 1])
          flag = false;
      }
      return flag;
    }

    public static bool GetBit(this byte b, int bitIndex)
    {
      return ((uint) b & (uint) (1 << bitIndex)) > 0U;
    }

    public static bool GetBooleanFromClass(System.Type type, string varName)
    {
      return (bool) type.GetField(varName, BindingFlags.Static | BindingFlags.Public).GetValue((object) null);
    }

    public static bool ColorTolerance(Color c1, Color c2, int percent, bool alpha = true)
    {
      if (percent <= 0)
        percent = 1;
      int int32 = Convert.ToInt32((double) percent * 1.5);
      if (alpha)
      {
        if (Math.Abs((int) c1.A - (int) c2.A) < int32 && Math.Abs((int) c1.R - (int) c2.R) < int32 && Math.Abs((int) c1.G - (int) c2.G) < int32)
          return Math.Abs((int) c1.B - (int) c2.B) < int32;
        return false;
      }
      if (Math.Abs((int) c1.R - (int) c2.R) < int32 && Math.Abs((int) c1.G - (int) c2.G) < int32)
        return Math.Abs((int) c1.B - (int) c2.B) < int32;
      return false;
    }

    public static bool ColorTolerance(Color c1, Color[] colors, int percent, bool alpha = true)
    {
      bool flag = false;
      if (percent <= 0)
        percent = 1;
      int int32 = Convert.ToInt32((double) percent * 1.5);
      foreach (Color color in colors)
      {
        if (alpha)
        {
          if ((Math.Abs((int) c1.A - (int) color.A) >= int32 || Math.Abs((int) c1.R - (int) color.R) >= int32 || Math.Abs((int) c1.G - (int) color.G) >= int32 ? 0 : (Math.Abs((int) c1.B - (int) color.B) < int32 ? 1 : 0)) != 0)
            flag = true;
        }
        else if ((Math.Abs((int) c1.R - (int) color.R) >= int32 || Math.Abs((int) c1.G - (int) color.G) >= int32 ? 0 : (Math.Abs((int) c1.B - (int) color.B) < int32 ? 1 : 0)) != 0)
          flag = true;
      }
      return flag;
    }

    public static bool ColorGrayscale(Color c, int radius)
    {
      return Math.Abs((int) Math.Max(c.R, Math.Max(c.G, c.B)) - (int) Math.Min(c.R, Math.Min(c.G, c.B))) < radius;
    }

    public static bool ColorGrayscale(Color[] colors, int radius)
    {
      bool flag = false;
      foreach (Color color in colors)
      {
        if (Math.Abs((int) Math.Max(color.R, Math.Max(color.G, color.B)) - (int) Math.Min(color.R, Math.Min(color.G, color.B))) < radius)
          flag = true;
      }
      return flag;
    }

    public static bool HasColor(Bitmap img, Color color)
    {
      DirectBitmap directBitmap = new DirectBitmap(img);
      for (int x = 0; x < directBitmap.Width; ++x)
      {
        for (int y = 0; y < directBitmap.Height; ++y)
        {
          if (directBitmap.GetPixel(x, y) == color)
            return true;
        }
      }
      directBitmap.Dispose();
      return false;
    }

    public static bool HasColors(Bitmap img, Color[] colors)
    {
      DirectBitmap directBitmap = new DirectBitmap(img);
      for (int x = 0; x < directBitmap.Width; ++x)
      {
        for (int y = 0; y < directBitmap.Height; ++y)
        {
          Color pixel = directBitmap.GetPixel(x, y);
          foreach (Color color in colors)
          {
            if (pixel == color)
              return true;
          }
        }
      }
      directBitmap.Dispose();
      return false;
    }

    public static bool HasAlphas(this Color[] colors)
    {
      foreach (Color color in colors)
      {
        if (color.A < byte.MaxValue)
          return true;
      }
      return false;
    }

    public static bool HasAlphas(this List<Color> colors)
    {
      foreach (Color color in colors)
      {
        if (color.A < byte.MaxValue)
          return true;
      }
      return false;
    }

    public static Color[] TruncateColors(this Color[] colors)
    {
      if (colors.Length <= 256)
        return colors;
      Color[] colorArray = new Color[256];
      Array.Copy((Array) colors, (Array) colorArray, 256);
      return colorArray;
    }

    public static Color GetClosestColor(Color[] palette, Color source)
    {
      int num = int.MaxValue;
      Color color = Color.Black;
      foreach (Color baseColor in palette)
      {
        int colorDifference = Methods.GetColorDifference(source, baseColor);
        if (colorDifference < num)
        {
          num = colorDifference;
          color = baseColor;
        }
      }
      return color;
    }

    public static int GetColorDifference(Color color, Color baseColor)
    {
      int num1 = (int) color.A - (int) baseColor.A;
      int num2 = (int) color.R - (int) baseColor.R;
      int num3 = (int) color.G - (int) baseColor.G;
      int num4 = (int) color.B - (int) baseColor.B;
      int num5 = num1 * num1;
      int num6 = num2;
      int num7 = num6 * num6;
      int num8 = num5 + num7;
      int num9 = num3;
      int num10 = num9 * num9;
      int num11 = num8 + num10;
      int num12 = num4;
      int num13 = num12 * num12;
      return num11 + num13;
    }

    public static Color GetBackgroundColor(this Bitmap bmp)
    {
      Dictionary<int, int> source = new Dictionary<int, int>();
      for (int y = 0; y < bmp.Height; ++y)
      {
        for (int x = 0; x < bmp.Width; ++x)
        {
          int num1 = Math.Ceiling((double) bmp.Height * 2.0 / 100.0).ToInt();
          int num2 = bmp.Height - num1;
          Color pixel;
          if (y < num1 || y > num2)
          {
            pixel = bmp.GetPixel(x, y);
            int argb = pixel.ToArgb();
            if (source.Keys.Contains<int>(argb))
              source[argb]++;
            else
              source.Add(argb, 1);
          }
          else
          {
            int num3 = Math.Ceiling((double) bmp.Width * 2.0 / 100.0).ToInt();
            int num4 = bmp.Width - num3;
            if (x < num3 || x > num4)
            {
              pixel = bmp.GetPixel(x, y);
              int argb = pixel.ToArgb();
              if (source.Keys.Contains<int>(argb))
                source[argb]++;
              else
                source.Add(argb, 1);
            }
          }
        }
      }
      return Color.FromArgb(new Dictionary<int, int>((IDictionary<int, int>) source.OrderByDescending<KeyValuePair<int, int>, int>((Func<KeyValuePair<int, int>, int>) (x => x.Value)).ToDictionary<KeyValuePair<int, int>, int, int>((Func<KeyValuePair<int, int>, int>) (x => x.Key), (Func<KeyValuePair<int, int>, int>) (x => x.Value))).First<KeyValuePair<int, int>>().Key);
    }

    public static List<Color> GetTopColors(this Bitmap source)
    {
      using (new Bitmap((Image) source))
        return Methods.GetPixels(source).GroupBy<Color, Color>((Func<Color, Color>) (color => color)).OrderByDescending<IGrouping<Color, Color>, int>((Func<IGrouping<Color, Color>, int>) (grp => grp.Count<Color>())).Select<IGrouping<Color, Color>, Color>((Func<IGrouping<Color, Color>, Color>) (grp => grp.Key)).Take<Color>(5).ToList<Color>();
    }

    public static Color GetBrightestColor(this Bitmap source, Color[] exceptions = null)
    {
      Color.FromArgb(0, 0, 0);
      Color color = Color.FromArgb(0, 0, 0);
      int num = 0;
      DirectBitmap directBitmap = new DirectBitmap(source);
      for (int y = 0; y < directBitmap.Height; ++y)
      {
        for (int x = 0; x < directBitmap.Width; ++x)
        {
          Color pixel = directBitmap.GetPixel(x, y);
          if (!((IEnumerable<Color>) exceptions).Contains<Color>(pixel))
          {
            int brightnessFactor = pixel.GetBrightnessFactor();
            if (brightnessFactor > num)
            {
              num = brightnessFactor;
              color = pixel;
            }
          }
        }
      }
      directBitmap.Dispose();
      return color;
    }

    public static Color[] CopyColors(this Color[] array, bool copyAlphas = true)
    {
      Color[] colorArray = new Color[array.Length];
      if (copyAlphas)
      {
        Array.Copy((Array) array, (Array) colorArray, array.Length);
      }
      else
      {
        int index = 0;
        foreach (Color color in array)
        {
          colorArray[index] = Color.FromArgb((int) byte.MaxValue, (int) color.R, (int) color.G, (int) color.B);
          ++index;
        }
      }
      return colorArray;
    }

    public static Color GetColorFromClass(System.Type type, string varName)
    {
      return (Color) type.GetField(varName, BindingFlags.Static | BindingFlags.Public).GetValue((object) null);
    }

    public static Color[] GetColorArrayFromClass(System.Type type, string varName)
    {
      return (Color[]) type.GetField(varName, BindingFlags.Static | BindingFlags.Public).GetValue((object) null);
    }

    public static Color[] TrimRowEnd(this Color[] colors, int trim)
    {
      List<Color> list = ((IEnumerable<Color>) colors).ToList<Color>();
      if (trim > 15)
        trim = 15;
      if (trim < 1)
        trim = 1;
      for (int index1 = colors.Length - 1; index1 >= 0; index1 -= 16)
      {
        for (int index2 = 0; index2 < trim; ++index2)
          list.RemoveAt(index1 - index2);
      }
      return list.ToArray();
    }

    public static Bitmap DrawPixels(this Bitmap bmp, int x, int y, Color color, int length = 1)
    {
      using (Graphics graphics = Graphics.FromImage((Image) bmp))
      {
        SolidBrush solidBrush = new SolidBrush(color);
        graphics.FillRectangle((Brush) solidBrush, new Rectangle(x, y, length, 1));
      }
      return bmp;
    }

    public static Bitmap MakeTransparent(this Bitmap bmp, Color color, int delta)
    {
      BitmapData bitmapdata = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadWrite, bmp.PixelFormat);
      long length = (long) (bitmapdata.Height * bitmapdata.Stride);
      byte[] numArray = new byte[length];
      Marshal.Copy(bitmapdata.Scan0, numArray, 0, numArray.Length);
      for (int index = 0; (long) index < length; index += 4)
      {
        if (Math.Abs((int) numArray[index + 0] - (int) color.B) + Math.Abs((int) numArray[index + 1] - (int) color.G) + Math.Abs((int) numArray[index + 2] - (int) color.R) <= delta)
          numArray[index + 3] = (byte) 0;
      }
      Marshal.Copy(numArray, 0, bitmapdata.Scan0, numArray.Length);
      bmp.UnlockBits(bitmapdata);
      return bmp;
    }

    public static Bitmap ConvertTo32BitColors(this Bitmap source)
    {
      return source.Clone(new Rectangle(0, 0, source.Width, source.Height), PixelFormat.Format32bppArgb);
    }

    public static Image ReplaceColor(this Image source, Color oldColor, Color newColor)
    {
      using (Graphics graphics = Graphics.FromImage(source))
      {
        ColorMap[] map = new ColorMap[1]
        {
          new ColorMap()
        };
        map[0].OldColor = oldColor;
        map[0].NewColor = newColor;
        ImageAttributes imageAttr = new ImageAttributes();
        imageAttr.SetRemapTable(map);
        Rectangle destRect = new Rectangle(0, 0, source.Width, source.Height);
        graphics.DrawImage(source, destRect, 0, 0, destRect.Width, destRect.Height, GraphicsUnit.Pixel, imageAttr);
      }
      return source;
    }

    public static Image SolidifyTransparency(this Image source)
    {
      Bitmap bitmap = new Bitmap(source);
      for (int y = 0; y < source.Height; ++y)
      {
        for (int x = 0; x < source.Width; ++x)
        {
          Color pixel = bitmap.GetPixel(x, y);
          if (pixel.A != byte.MaxValue)
            bitmap.SetPixel(x, y, Color.FromArgb((int) byte.MaxValue, (int) pixel.R, (int) pixel.G, (int) pixel.B));
        }
      }
      return (Image) bitmap;
    }

    public static Image ZoomGraphic(this Image source, double percentage)
    {
      if (percentage == 100.0)
        return source;
      int num1 = (int) (percentage / 100.0);
      int width = source.Width * num1;
      int height = source.Height * num1;
      if (source.Width * source.Height > 250000)
      {
        source = (Image) new Bitmap(source, width, height);
      }
      else
      {
        DirectBitmap directBitmap1 = new DirectBitmap(source);
        DirectBitmap directBitmap2 = new DirectBitmap(width, height);
        for (int y1 = 0; y1 < directBitmap1.Height; ++y1)
        {
          for (int x1 = 0; x1 < directBitmap1.Width; ++x1)
          {
            Color pixel = directBitmap1.GetPixel(x1, y1);
            int num2 = 1;
            while (x1 + num2 < directBitmap1.Width && directBitmap1.GetPixel(x1 + num2, y1) == pixel)
              ++num2;
            for (int y2 = y1 * num1; y2 < y1 * num1 + num1; ++y2)
            {
              for (int x2 = x1 * num1; x2 < x1 * num1 + num2 * num1; ++x2)
                directBitmap2.SetPixel(x2, y2, pixel);
            }
            if (num2 > 1)
              x1 += num2 - 1;
          }
        }
        source = (Image) new Bitmap((Image) directBitmap2.Bitmap);
        directBitmap1.Dispose();
        directBitmap2.Dispose();
      }
      return source;
    }

    public static Bitmap AutoCropGraphic(this Bitmap source, Color bkg)
    {
      return source.AutoCropGraphic(new Color[1]{ bkg });
    }

    public static Bitmap AutoCropGraphic(this Bitmap source, Color[] bkg)
    {
      int leftMargin = Methods.GetLeftMargin(source, bkg, true);
      int rightMargin = Methods.GetRightMargin(source, bkg, true);
      int topMargin = Methods.GetTopMargin(source, bkg, true);
      int bottomMargin = Methods.GetBottomMargin(source, bkg, true);
      int width = source.Width - leftMargin - rightMargin;
      int height = source.Height - topMargin - bottomMargin;
      return source.CropGraphic(new Rectangle(leftMargin, topMargin, width, height));
    }

    public static Bitmap SetClosestColors(this Bitmap source, Color[] colors)
    {
      DirectBitmap directBitmap = new DirectBitmap(source);
      for (int y = 0; y < directBitmap.Height; ++y)
      {
        for (int x = 0; x < directBitmap.Width; ++x)
        {
          Color pixel = directBitmap.GetPixel(x, y);
          if (!((IEnumerable<Color>) colors).Contains<Color>(pixel))
            directBitmap.SetPixel(x, y, Methods.GetClosestColor(colors, pixel));
        }
      }
      return directBitmap.Bitmap;
    }

    public static Bitmap CreateSimpleDataGraphic(Bitmap source, Color bkg)
    {
      DirectBitmap directBitmap = new DirectBitmap(source);
      for (int y = 0; y < directBitmap.Height; ++y)
      {
        for (int x = 0; x < directBitmap.Width; ++x)
        {
          if (directBitmap.GetPixel(x, y) == bkg)
            directBitmap.SetPixel(x, y, Color.FromArgb((int) byte.MaxValue, 0, (int) byte.MaxValue));
          else
            directBitmap.SetPixel(x, y, Color.FromArgb((int) byte.MaxValue, (int) byte.MaxValue, (int) byte.MaxValue));
        }
      }
      return directBitmap.Bitmap;
    }

    //public static Bitmap GaussianBlur(this Bitmap source, int radius)
    //{
    //  return new Bitmap((Image) new GaussianBlur()
    //  {
    //    Radius = radius
    //  }.ProcessImage((Image) source));
    //}

    public static Bitmap DecreaseEdges(this Bitmap source, int thickness, Color bkg)
    {
      Bitmap bitmap = new Bitmap((Image) source);
      for (int index = 0; index < thickness; ++index)
      {
        for (int y = 0; y < source.Height; ++y)
        {
          for (int x = 0; x < source.Width; ++x)
          {
            if (source.GetPixel(x, y) != bkg && (x + 1 < source.Width && source.GetPixel(x + 1, y) == bkg || y + 1 < source.Height && source.GetPixel(x, y + 1) == bkg || (x - 1 >= 0 && source.GetPixel(x - 1, y) == bkg || y - 1 >= 0 && source.GetPixel(x, y - 1) == bkg)))
              bitmap.SetPixel(x, y, bkg);
          }
        }
        source = new Bitmap((Image) bitmap);
      }
      return bitmap;
    }

    public static Bitmap TextureToTerrainMap(
      this Bitmap source,
      int rows,
      int columns,
      int midX = 0,
      int midY = 0)
    {
      if (midX == 0)
        midX = Global.tileMidX;
      if (midY == 0)
        midY = Global.tileMidY;
      int width = midX * rows + midX * columns + 1;
      int height = midY * rows + midY * columns + 1;
      Bitmap bitmap1 = new Bitmap(width, height);
      if (source != null)
      {
        Point topleft = new Point(midX * rows, 0);
        Point topright = new Point(width + 2, midY * columns + 1);
        Point bottomleft = new Point(0, midY * rows + 1);
        Point bottomright = new Point(midX * columns, height + 2);
                Bitmap bitmap2 = new Bitmap("dd");// QuadDistort.Distort(source, topleft, topright, bottomleft, bottomright);
        using (Graphics graphics = Graphics.FromImage((Image) bitmap2))
        {
          graphics.DrawImage((Image) bitmap2, new Point(0, 0));
          graphics.DrawImage((Image) bitmap2, new Point(0, 0));
        }
        using (Graphics graphics = Graphics.FromImage((Image) bitmap1))
        {
          graphics.DrawImage((Image) bitmap2, new Point(-2, 0));
          graphics.DrawImage((Image) bitmap2, new Point(2, 0));
          graphics.DrawImage((Image) bitmap2, new Point(-1, 0));
        }
        Color pixel1 = source.GetPixel(0, 0);
        bitmap1.SetPixel(midX * rows, 0, pixel1);
        Bitmap bitmap3 = source;
        Color pixel2 = bitmap3.GetPixel(bitmap3.Width - 1, 0);
        bitmap1.SetPixel(width - 1, midY * columns, pixel2);
        Color pixel3 = source.GetPixel(0, source.Height - 1);
        bitmap1.SetPixel(0, midY * rows, pixel3);
        Bitmap bitmap4 = source;
        Color pixel4 = bitmap4.GetPixel(bitmap4.Width - 1, source.Height - 1);
        bitmap1.SetPixel(midX * columns, height - 1, pixel4);
        bitmap2.Dispose();
      }
      else
      {
        using (Graphics graphics = Graphics.FromImage((Image) bitmap1))
          graphics.Clear(Color.White);
      }
      int num1 = midX * rows;
      int num2 = 1;
      int num3 = 0;
      for (int y = 0; y < bitmap1.Height; ++y)
      {
        if (source != null && y == 0 && (num1 >= 0 && num1 < bitmap1.Width))
          bitmap1.SetPixel(num1, 0, source.GetPixel(0, 0));
        if (source != null && y >= midY * rows)
        {
          int num4 = height - midY * rows;
          int x = Math.Round((Decimal) source.Width * ((Decimal) num3 / (Decimal) num4)).ToInt();
          Color pixel1 = source.GetPixel(x, source.Height - 1);
          if (num1 >= 0 && num1 < bitmap1.Width)
            bitmap1.SetPixel(num1, y, pixel1);
          if (x < source.Width - 1)
          {
            Color pixel2 = source.GetPixel(x + 1, source.Height - 2);
            if (num1 >= 0 && num1 < bitmap1.Width)
              bitmap1.SetPixel(num1 + 1, y, pixel2);
          }
          ++num3;
        }
        SolidBrush solidBrush = new SolidBrush(Color.FromArgb((int) byte.MaxValue, 0, (int) byte.MaxValue));
        using (Graphics graphics = Graphics.FromImage((Image) bitmap1))
        {
          graphics.FillRectangle((Brush) solidBrush, new Rectangle(0, y, num1, 1));
          graphics.FillRectangle((Brush) solidBrush, new Rectangle(num1 + num2, y, num1, 1));
        }
        if (y < (bitmap1.Height - 1) / 2)
        {
          num2 += 4;
          num1 -= 2;
        }
        else
        {
          num2 -= 4;
          num1 += 2;
        }
      }
      source?.Dispose();
      return bitmap1;
    }

    public static Bitmap FramesToTerrainMap(
      List<Bitmap> frames,
      int numRows,
      int numColumns,
      bool mask = true)
    {
      if (frames.Count > 0 && frames.Count < 4)
        return frames[0];
      if (frames.Count == 0)
        return new Bitmap(1, 1);
      int width = frames[0].Width;
      int height = frames[0].Height;
      int midX = (width - 1) / 2;
      int midY = (height - 1) / 2;
      Bitmap terrainMap = ((Bitmap) null).TextureToTerrainMap(numRows, numColumns, midX, midY);
      terrainMap.ReplaceColor(Color.FromArgb((int) byte.MaxValue, (int) byte.MaxValue, (int) byte.MaxValue), Color.FromArgb((int) byte.MaxValue, 0, (int) byte.MaxValue));
      if (!mask)
        terrainMap.MakeTransparent(Color.FromArgb((int) byte.MaxValue, 0, (int) byte.MaxValue));
      else
        terrainMap.ReplaceColor(Color.FromArgb((int) byte.MaxValue, 0, (int) byte.MaxValue), Global.sxpMaskColor);
      int x = 0;
      int y = midY * numRows - midY;
      int index1 = 0;
      for (int index2 = 1; index2 <= numColumns; ++index2)
      {
        for (int index3 = 1; index3 <= numRows; ++index3)
        {
          if (index1 < frames.Count)
          {
            Bitmap bitmap = new Bitmap((Image) frames[index1]);
            using (Graphics graphics = Graphics.FromImage((Image) terrainMap))
              graphics.DrawImage((Image) bitmap, new Point(x, y));
            if (index3 < numRows)
            {
              x += midX;
              y -= midY;
            }
            else if (numRows != 1 && index3 == numRows)
            {
              x -= midX * (numRows - 2);
              y += midY * numRows;
            }
            bitmap.Dispose();
            ++index1;
            if (index1 >= frames.Count)
              break;
          }
        }
      }
      return terrainMap;
    }

    public static int GetTerrainMapRows(Bitmap source)
    {
      int tileMidX = Global.tileMidX;
      Bitmap source1 = new Bitmap((Image) source);
      Color pixel = source1.GetPixel(0, 0);
      if (source1.Width == 981 || source1.Height == 481)
        source1 = source1.ResizeGraphic(961, 481, 1);
      int num = 0;
      for (int x = tileMidX; x < source1.Width; x += tileMidX)
      {
        if (source1.GetPixel(x, 0) != pixel)
        {
          num = x;
          break;
        }
      }
      if (num == 0)
        return 0;
      return num / tileMidX;
    }

    public static int GetTerrainMapColumns(Bitmap source)
    {
      int tileMidY = Global.tileMidY;
      Bitmap source1 = new Bitmap((Image) source);
      Color pixel = source1.GetPixel(0, 0);
      if (source1.Width == 981 || source1.Height == 481)
        source1 = source1.ResizeGraphic(961, 481, 1);
      int num = 0;
      for (int y = tileMidY; y < source1.Height; y += tileMidY)
      {
        if (source1.GetPixel(0, y) != pixel)
        {
          num = y;
          break;
        }
      }
      if (num == 0)
        return 0;
      return (source1.Height - 1 - num) / tileMidY;
    }

    public static Bitmap TerrainMapToTextureImage(this Bitmap source)
    {
      int tileMidX = Global.tileMidX;
      int tileMidY = Global.tileMidY;
      Bitmap source1 = new Bitmap((Image) source);
      Color pixel = source1.GetPixel(0, 0);
      if (source1.Width == 981 || source1.Height == 481)
        source1 = source1.ResizeGraphic(961, 481, 1);
      int num1 = 0;
      int y1 = 0;
      for (int x = tileMidX; x < source1.Width; x += tileMidX)
      {
        if (source1.GetPixel(x, 0) != pixel)
        {
          num1 = x;
          break;
        }
      }
      for (int y2 = tileMidY; y2 < source1.Height; y2 += tileMidY)
      {
        if (source1.GetPixel(0, y2) != pixel)
        {
          y1 = y2;
          break;
        }
      }
      if (num1 == 0 || y1 == 0)
      {
        int num2 = (int) MessageBox.Show("Unable to determine tile size.", "Error");
        return (Bitmap) null;
      }
      int num3 = num1 / tileMidX;
      int num4 = (source1.Height - 1 - y1) / tileMidY;
      Bitmap image1 = source1;
      Color color1 = pixel;
      Bitmap image2 = image1.DrawOutline(color1, color1);
      Color color2 = pixel;
      Bitmap sourceBitmap = image2.DrawOutline(color2, color2);
      sourceBitmap.MakeTransparent(pixel);
      Point topleft = new Point(0, 0);
      Point topright = new Point(sourceBitmap.Width, 0);
      Point bottomleft = new Point(0, (sourceBitmap.Height - 1) * 2);
      Point bottomright = new Point(sourceBitmap.Width, (sourceBitmap.Height - 1) * 2);
            Bitmap source2 = new Bitmap("dss");// QuadDistort.Distort(sourceBitmap, topleft, topright, bottomleft, bottomright).RotateGraphic(-45f, false);
      Color color3 = Color.FromArgb(0, 0, 0);
      int x1 = 0;
      int num5 = source2.Width;
      int y3 = 0;
      int num6 = source2.Height;
      int x2 = Math.Round((double) source2.Width / 2.0).ToInt();
      int y4 = Math.Round((double) source2.Height / 2.0).ToInt();
      for (int x3 = 0; x3 < source2.Width; ++x3)
      {
        if (source2.GetPixel(x3, y4) != color3)
        {
          x1 = x3 + 3;
          break;
        }
      }
      for (int x3 = source2.Width - 1; x3 > x1; --x3)
      {
        if (source2.GetPixel(x3, y4) != color3)
        {
          num5 = x3 - 1;
          break;
        }
      }
      for (int y2 = 0; y2 < source2.Height; ++y2)
      {
        if (source2.GetPixel(x2, y2) != color3)
        {
          y3 = y2 + 3;
          break;
        }
      }
      for (int y2 = source2.Height - 1; y2 > y3; --y2)
      {
        if (source2.GetPixel(x2, y2) != color3)
        {
          num6 = y2 - 3;
          break;
        }
      }
      Bitmap image3 = source2.CropGraphic(new Rectangle(x1, y3, num5 - x1, num6 - y3));
      image3.SetPixel(0, 0, source.GetPixel(num1 - 1, 0));
      image3.SetPixel(0, 1, source.GetPixel(num1 - 3, 1));
      image3.SetPixel(1, 0, source.GetPixel(num1 + 1, 1));
      image3.SetPixel(0, image3.Height - 1, source.GetPixel(0, y1 - 1));
      image3.SetPixel(0, image3.Height - 2, source.GetPixel(2, y1 - 2));
      image3.SetPixel(1, image3.Height - 1, source.GetPixel(2, y1));
      return image3.SharpenGraphic(0.9);
    }

    public static Bitmap CropGraphic(this Bitmap source, Rectangle r)
    {
      Bitmap bitmap1 = new Bitmap((Image) source);
      Bitmap bitmap2 = new Bitmap(r.Width, r.Height);
      Graphics.FromImage((Image) bitmap2).DrawImage((Image) bitmap1, -r.X, -r.Y);
      return bitmap2;
    }

    public static Image TransparentCheckerboard(int width, int height)
    {
      Image image = (Image) new Bitmap(width, height);
      for (int y = 1; y < image.Height; y = y + 20 + 1)
      {
        for (int x = 1; x < image.Width; x = x + 20 + 1)
        {
          SolidBrush solidBrush1 = new SolidBrush(Color.FromArgb((int) byte.MaxValue, (int) byte.MaxValue, (int) byte.MaxValue));
          using (Graphics graphics = Graphics.FromImage(image))
          {
            graphics.FillRectangle((Brush) solidBrush1, new Rectangle(x, y, 20, 20));
            SolidBrush solidBrush2 = new SolidBrush(Color.FromArgb(204, 204, 204));
            graphics.FillRectangle((Brush) solidBrush2, new Rectangle(x + 0, y, 5, 5));
            graphics.FillRectangle((Brush) solidBrush2, new Rectangle(x + 10, y, 5, 5));
            graphics.FillRectangle((Brush) solidBrush2, new Rectangle(x + 5, y + 5, 5, 5));
            graphics.FillRectangle((Brush) solidBrush2, new Rectangle(x + 15, y + 5, 5, 5));
            graphics.FillRectangle((Brush) solidBrush2, new Rectangle(x + 0, y + 10, 5, 5));
            graphics.FillRectangle((Brush) solidBrush2, new Rectangle(x + 10, y + 10, 5, 5));
            graphics.FillRectangle((Brush) solidBrush2, new Rectangle(x + 5, y + 15, 5, 5));
            graphics.FillRectangle((Brush) solidBrush2, new Rectangle(x + 15, y + 15, 5, 5));
          }
        }
      }
      return image;
    }

    public static Bitmap MergeGraphics(
      this Bitmap source,
      int centerX,
      int centerY,
      Color bkg,
      Bitmap overlay,
      int posX,
      int posY,
      bool overlayMask = false)
    {
      int width = source.Width;
      int height = source.Height;
      int x = (centerX - posX) * -1;
      int num1 = (width - centerX - (overlay.Width - posX)) * -1;
      int y = (centerY - posY) * -1;
      int num2 = (height - centerY - (overlay.Height - posY)) * -1;
      if (x > 0)
        width += x;
      else
        x = 0;
      if (num1 > 0)
        width += num1;
      if (y > 0)
        height += y;
      else
        y = 0;
      if (num2 > 0)
        height += num2;
      Bitmap bitmap = new Bitmap(width, height);
      Graphics graphics = Graphics.FromImage((Image) bitmap);
      graphics.Clear(bkg);
      graphics.DrawImage((Image) source, x, y);
      if (overlayMask)
        overlay.MakeTransparent();
      graphics.DrawImage((Image) overlay, x + centerX - posX, y + centerY - posY);
      return bitmap;
    }

    public static Bitmap MirrorGraphic(this Bitmap source, bool verticalFlip = false)
    {
      Bitmap bitmap = new Bitmap((Image) source);
      if (!verticalFlip)
        bitmap.RotateFlip(RotateFlipType.RotateNoneFlipX);
      else
        bitmap.RotateFlip(RotateFlipType.Rotate180FlipX);
      return bitmap;
    }

    public static Bitmap RotateGraphic(this Bitmap source, float angle, bool resize = false)
    {
      Bitmap bitmap = new Bitmap(source.Width, source.Height);
      int width1 = source.Width;
      int height1 = source.Height;
      double num1 = (double) angle * Math.PI / 180.0;
      double num2 = Math.Abs(Math.Cos(num1));
      double num3 = Math.Abs(Math.Sin(num1));
      int width2 = (int) ((double) width1 * num2 + (double) height1 * num3);
      int height2 = (int) ((double) width1 * num3 + (double) height1 * num2);
      if (resize)
        bitmap = new Bitmap(width2, height2);
      Graphics graphics = Graphics.FromImage((Image) bitmap);
      if (resize)
        graphics.TranslateTransform((float) (width2 - width1) / 2f, (float) (height2 - height1) / 2f);
      graphics.TranslateTransform((float) source.Width / 2f, (float) source.Height / 2f);
      graphics.RotateTransform(angle);
      graphics.TranslateTransform((float) (-(double) source.Width / 2.0), (float) (-(double) source.Height / 2.0));
      graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
      graphics.DrawImage((Image) source, new Point(0, 0));
      graphics.Dispose();
      return bitmap;
    }

    public static Bitmap ResizeGraphic(this Bitmap source, int width, int height, int iMode)
    {
      Bitmap bitmap = new Bitmap(width, height, PixelFormat.Format32bppArgb);
      using (Graphics graphics = Graphics.FromImage((Image) bitmap))
      {
        switch (iMode)
        {
          case 0:
            graphics.InterpolationMode = InterpolationMode.NearestNeighbor;
            break;
          case 1:
            graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
            break;
          case 2:
            graphics.InterpolationMode = InterpolationMode.HighQualityBilinear;
            break;
        }
        ImageAttributes imageAttr = new ImageAttributes();
        imageAttr.SetWrapMode(WrapMode.TileFlipXY);
        Rectangle destRect = new Rectangle(0, 0, width, height);
        graphics.DrawImage((Image) source, destRect, 0, 0, source.Width, source.Height, GraphicsUnit.Pixel, imageAttr);
      }
      return bitmap;
    }

    public static Image ResizeGraphic(Image source, int width, int height, bool antiAlias = true)
    {
      Bitmap bitmap = new Bitmap(width, height);
      using (Graphics graphics = Graphics.FromImage((Image) bitmap))
      {
        graphics.InterpolationMode = !antiAlias ? InterpolationMode.NearestNeighbor : InterpolationMode.HighQualityBicubic;
        ImageAttributes imageAttr = new ImageAttributes();
        imageAttr.SetWrapMode(WrapMode.TileFlipXY);
        Rectangle destRect = new Rectangle(0, 0, width, height);
        graphics.DrawImage(source, destRect, 0, 0, source.Width, source.Height, GraphicsUnit.Pixel, imageAttr);
      }
      return (Image) bitmap;
    }

    public static Bitmap FixBorder(this Bitmap source, int tolerance, Color? bkg = null)
    {
      Color empty = Color.Empty;
      Color color = !bkg.HasValue ? source.GetBackgroundColor() : bkg ?? Color.Empty;
      for (int x = 0; x < source.Width; ++x)
      {
        if (Methods.ColorTolerance(source.GetPixel(x, 0), color, tolerance, true))
          source.SetPixel(x, 0, color);
        if (Methods.ColorTolerance(source.GetPixel(x, source.Height - 1), color, tolerance, true))
          source.SetPixel(x, source.Height - 1, color);
      }
      for (int y = 0; y < source.Height; ++y)
      {
        if (Methods.ColorTolerance(source.GetPixel(0, y), color, tolerance, true))
          source.SetPixel(0, y, color);
        Bitmap bitmap1 = source;
        if (Methods.ColorTolerance(bitmap1.GetPixel(bitmap1.Width - 1, y), color, tolerance, true))
        {
          Bitmap bitmap2 = source;
          bitmap2.SetPixel(bitmap2.Width - 1, y, color);
        }
      }
      if (Methods.ColorTolerance(source.GetPixel(0, 0), color, tolerance, true))
        source.SetPixel(0, 0, color);
      Bitmap bitmap3 = source;
      if (Methods.ColorTolerance(bitmap3.GetPixel(bitmap3.Width - 1, 0), color, tolerance, true))
      {
        Bitmap bitmap1 = source;
        bitmap1.SetPixel(bitmap1.Width - 1, 0, color);
      }
      if (Methods.ColorTolerance(source.GetPixel(0, source.Height - 1), color, tolerance, true))
        source.SetPixel(0, source.Height - 1, color);
      Bitmap bitmap4 = source;
      if (Methods.ColorTolerance(bitmap4.GetPixel(bitmap4.Width - 1, source.Height - 1), color, tolerance, true))
      {
        Bitmap bitmap1 = source;
        bitmap1.SetPixel(bitmap1.Width - 1, source.Height - 1, color);
      }
      return source;
    }

    public static Bitmap ResizeCanvas(
      this Bitmap source,
      int width,
      int height,
      Color? background = null)
    {
      Bitmap bitmap = new Bitmap(width, height);
      using (Graphics graphics = Graphics.FromImage((Image) bitmap))
      {
        if (background.HasValue)
        {
          SolidBrush solidBrush = new SolidBrush(background.Value);
          graphics.FillRectangle((Brush) solidBrush, new Rectangle(0, 0, bitmap.Width, bitmap.Height));
        }
        graphics.DrawImage((Image) source, new Point(Math.Abs(bitmap.Width - source.Width) / 2, Math.Abs(bitmap.Height - source.Height) / 2));
      }
      return bitmap;
    }

    public static Bitmap ResizeTerrainMap(Bitmap source)
    {
      Point topleft = new Point(0, 0);
      Point topright = new Point(961, 0);
      Point bottomleft = new Point(0, 481);
      Point bottomright = new Point(961, 481);
      source = new Bitmap("");
      return source;
    }

    public static IEnumerable<Color> GetPixels(Bitmap source)
    {
      DirectBitmap db = new DirectBitmap(source);
      for (int x = 0; x < db.Width; ++x)
      {
        for (int y = 0; y < db.Height; ++y)
          yield return db.GetPixel(x, y);
      }
    }

    public static Bitmap SetBrightness(this Bitmap image, int value)
    {
      DirectBitmap directBitmap = new DirectBitmap(image);
      if (value < -255)
        value = -255;
      if (value > (int) byte.MaxValue)
        value = (int) byte.MaxValue;
      for (int x = 0; x < directBitmap.Width; ++x)
      {
        for (int y = 0; y < directBitmap.Height; ++y)
        {
          Color pixel = directBitmap.GetPixel(x, y);
          int red = (int) pixel.R + value;
          int green = (int) pixel.G + value;
          int blue = (int) pixel.B + value;
          if (red < 0)
            red = 1;
          if (red > (int) byte.MaxValue)
            red = (int) byte.MaxValue;
          if (green < 0)
            green = 1;
          if (green > (int) byte.MaxValue)
            green = (int) byte.MaxValue;
          if (blue < 0)
            blue = 1;
          if (blue > (int) byte.MaxValue)
            blue = (int) byte.MaxValue;
          directBitmap.SetPixel(x, y, Color.FromArgb(red, green, blue));
        }
      }
      return directBitmap.Bitmap;
    }

    public static Bitmap SharpenGraphic(this Bitmap image, double strength)
    {
      using (Bitmap bitmap1 = image)
      {
        if (bitmap1 != null)
        {
          Bitmap bitmap2 = bitmap1.Clone() as Bitmap;
          int width = image.Width;
          int height = image.Height;
          double[,] numArray1 = new double[5, 5]
          {
            {
              -1.0,
              -1.0,
              -1.0,
              -1.0,
              -1.0
            },
            {
              -1.0,
              2.0,
              2.0,
              2.0,
              -1.0
            },
            {
              -1.0,
              2.0,
              16.0,
              2.0,
              -1.0
            },
            {
              -1.0,
              2.0,
              2.0,
              2.0,
              -1.0
            },
            {
              -1.0,
              -1.0,
              -1.0,
              -1.0,
              -1.0
            }
          };
          double num1 = 1.0 - strength;
          double num2 = strength / 16.0;
          Color[,] colorArray = new Color[image.Width, image.Height];
          if (bitmap2 != null)
          {
            BitmapData bitmapdata = bitmap2.LockBits(new Rectangle(0, 0, width, height), ImageLockMode.ReadWrite, PixelFormat.Format24bppRgb);
            int length = bitmapdata.Stride * height;
            byte[] numArray2 = new byte[length];
            Marshal.Copy(bitmapdata.Scan0, numArray2, 0, length);
            for (int index1 = 2; index1 < width - 2; ++index1)
            {
              for (int index2 = 2; index2 < height - 2; ++index2)
              {
                double num3 = 0.0;
                double num4 = 0.0;
                double num5 = 0.0;
                for (int index3 = 0; index3 < 5; ++index3)
                {
                  for (int index4 = 0; index4 < 5; ++index4)
                  {
                    int num6 = (index1 - 2 + index3 + width) % width;
                    int num7 = (index2 - 2 + index4 + height) % height * bitmapdata.Stride + 3 * num6;
                    num3 += (double) numArray2[num7 + 2] * numArray1[index3, index4];
                    num4 += (double) numArray2[num7 + 1] * numArray1[index3, index4];
                    num5 += (double) numArray2[num7 + 0] * numArray1[index3, index4];
                  }
                  int num8 = index2 * bitmapdata.Stride + 3 * index1;
                  int red = Math.Min(Math.Max((int) (num2 * num3 + num1 * (double) numArray2[num8 + 2]), 0), (int) byte.MaxValue);
                  int green = Math.Min(Math.Max((int) (num2 * num4 + num1 * (double) numArray2[num8 + 1]), 0), (int) byte.MaxValue);
                  int blue = Math.Min(Math.Max((int) (num2 * num5 + num1 * (double) numArray2[num8 + 0]), 0), (int) byte.MaxValue);
                  colorArray[index1, index2] = Color.FromArgb(red, green, blue);
                }
              }
            }
            for (int index1 = 2; index1 < width - 2; ++index1)
            {
              for (int index2 = 2; index2 < height - 2; ++index2)
              {
                int num3 = index2 * bitmapdata.Stride + 3 * index1;
                numArray2[num3 + 2] = colorArray[index1, index2].R;
                numArray2[num3 + 1] = colorArray[index1, index2].G;
                numArray2[num3 + 0] = colorArray[index1, index2].B;
              }
            }
            Marshal.Copy(numArray2, 0, bitmapdata.Scan0, length);
            bitmap2.UnlockBits(bitmapdata);
          }
          return bitmap2;
        }
      }
      return (Bitmap) null;
    }

    public static Bitmap SetOpacity(this Bitmap image, float opacity, Color? omit = null)
    {
      if ((double) opacity <= 0.0)
        return new Bitmap(image.Width, image.Height);
      DirectBitmap directBitmap = new DirectBitmap(image);
      for (int y = 0; y < directBitmap.Height; ++y)
      {
        for (int x = 0; x < directBitmap.Width; ++x)
        {
          Color colour = directBitmap.GetPixel(x, y);
          int alpha = Math.Ceiling((double) colour.A * (double) opacity).ToInt();
          if (alpha > (int) byte.MaxValue)
            alpha = (int) byte.MaxValue;
          else if (alpha < 0)
            alpha = 0;
          Color color = colour;
          Color? nullable = omit;
          if ((nullable.HasValue ? (color == nullable.GetValueOrDefault() ? 1 : 0) : 0) == 0)
          {
            colour = Color.FromArgb(alpha, (int) colour.R, (int) colour.G, (int) colour.B);
            directBitmap.SetPixel(x, y, colour);
          }
        }
      }
      return directBitmap.Bitmap;
    }

    public static Bitmap DrawOutline(this Bitmap image, Color color, Color bkgColor)
    {
      DirectBitmap directBitmap1 = new DirectBitmap(image);
      DirectBitmap directBitmap2 = new DirectBitmap(image);
      for (int x = 0; x < directBitmap1.Width - 1; ++x)
      {
        for (int y = 0; y < directBitmap1.Height - 1; ++y)
        {
          if (directBitmap1.GetPixel(x, y) == bkgColor && x != 0 && (x != directBitmap1.Width && y != 0) && y != directBitmap1.Height && (directBitmap1.GetPixel(x - 1, y) != bkgColor || directBitmap1.GetPixel(x + 1, y) != bkgColor || (directBitmap1.GetPixel(x, y - 1) != bkgColor || directBitmap1.GetPixel(x, y + 1) != bkgColor)))
            directBitmap2.SetPixel(x, y, color);
        }
      }
      directBitmap1.Dispose();
      return directBitmap2.Bitmap;
    }

    public static Bitmap DrawOutline(this Bitmap image, Color color, Color[] bkgColors)
    {
      DirectBitmap directBitmap = new DirectBitmap(image);
      for (int x = 0; x < directBitmap.Width; ++x)
      {
        for (int y = 0; y < directBitmap.Height; ++y)
        {
          Color pixel = directBitmap.GetPixel(x, y);
          if (((IEnumerable<Color>) bkgColors).Contains<Color>(pixel) && x != 0 && (x != directBitmap.Width && y != 0) && y != directBitmap.Height && (!((IEnumerable<Color>) bkgColors).Contains<Color>(directBitmap.GetPixel(x - 1, y)) || !((IEnumerable<Color>) bkgColors).Contains<Color>(directBitmap.GetPixel(x + 1, y)) || (!((IEnumerable<Color>) bkgColors).Contains<Color>(directBitmap.GetPixel(x, y - 1)) || !((IEnumerable<Color>) bkgColors).Contains<Color>(directBitmap.GetPixel(x, y + 1)))))
            directBitmap.SetPixel(x, y, color);
        }
      }
      return directBitmap.Bitmap;
    }

    public static ImageFormat GetCurrentFormat()
    {
      if (Global.currentFormat == ".bmp")
        return ImageFormat.Bmp;
      int num = Global.currentFormat == ".png" ? 1 : 0;
      return ImageFormat.Png;
    }

    public static float GetScalingFactor(Form form)
    {
      IntPtr hdc = Graphics.FromHwnd(IntPtr.Zero).GetHdc();
      float num = (float) Methods.GetDeviceCaps(hdc, 117) / (float) Methods.GetDeviceCaps(hdc, 10);
      if ((double) num == 1.0)
        num = form.CreateGraphics().DpiX / 96f;
      return num;
    }

    [DllImport("gdi32.dll")]
    private static extern int GetDeviceCaps(IntPtr hdc, int nIndex);

    public static Bitmap GenerateImageDiffusion(
      this Bitmap image,
      Color[] palette,
      float intensity)
    {
      Color backgroundColor = image.GetBackgroundColor();
      bool flag = false;
      if (backgroundColor.R >= (byte) 245 || backgroundColor.G >= (byte) 245 || backgroundColor.B >= (byte) 245)
        flag = true;
      else if (backgroundColor.A == (byte) 0)
        flag = true;
      DirectBitmap directBitmap = new DirectBitmap(image);
      intensity *= 0.01f;
      int height = image.Height;
      int width = image.Width;
      for (int y = 0; y < height; ++y)
      {
        for (int x = 0; x < width; ++x)
        {
          Color pixel1 = directBitmap.GetPixel(x, y);
          if (flag)
          {
            int num = 0;
            if (Methods.ColorTolerance(directBitmap.GetPixel(x + num, y), backgroundColor, 10, true))
            {
              num = 1;
              while (Methods.ColorTolerance(directBitmap.GetPixel(x + num, y), backgroundColor, 10, true))
              {
                ++num;
                if (x + num >= directBitmap.Width - 1)
                  break;
              }
            }
            if (x + num < directBitmap.Width - 1)
            {
              if (num >= 1)
              {
                x += num;
                pixel1 = directBitmap.GetPixel(x, y);
              }
            }
            else
              break;
          }
          Color closestColor = Methods.GetClosestColor(palette, pixel1);
          directBitmap.SetPixel(x, y, closestColor);
          int num1 = (int) pixel1.R - (int) closestColor.R;
          int num2 = (int) pixel1.G - (int) closestColor.G;
          int num3 = (int) pixel1.B - (int) closestColor.B;
          if (x + 1 < width)
          {
            Color pixel2 = directBitmap.GetPixel(x + 1, y + 0);
            directBitmap.SetPixel(x + 1, y + 0, Color.FromArgb((int) Methods.Truncate(pixel2.R, (int) ((double) (num1 * 7) * (double) intensity) >> 4), (int) Methods.Truncate(pixel2.G, (int) ((double) (num2 * 7) * (double) intensity) >> 4), (int) Methods.Truncate(pixel2.B, (int) ((double) (num3 * 7) * (double) intensity) >> 4)));
          }
          if (y + 1 < height)
          {
            if (x - 1 > 0)
            {
              Color pixel2 = directBitmap.GetPixel(x - 1, y + 1);
              directBitmap.SetPixel(x - 1, y + 1, Color.FromArgb((int) Methods.Truncate(pixel2.R, (int) ((double) (num1 * 3) * (double) intensity) >> 4), (int) Methods.Truncate(pixel2.G, (int) ((double) (num2 * 3) * (double) intensity) >> 4), (int) Methods.Truncate(pixel2.B, (int) ((double) (num3 * 3) * (double) intensity) >> 4)));
            }
            Color pixel3 = directBitmap.GetPixel(x, y + 1);
            directBitmap.SetPixel(x, y + 1, Color.FromArgb((int) Methods.Truncate(pixel3.R, (int) ((double) (num1 * 5) * (double) intensity) >> 4), (int) Methods.Truncate(pixel3.G, (int) ((double) (num2 * 5) * (double) intensity) >> 4), (int) Methods.Truncate(pixel3.B, (int) ((double) (num3 * 5) * (double) intensity) >> 4)));
            if (x + 1 < width)
            {
              Color pixel2 = directBitmap.GetPixel(x + 1, y + 1);
              directBitmap.SetPixel(x + 1, y + 1, Color.FromArgb((int) Methods.Truncate(pixel2.R, (int) ((double) (num1 * 1) * (double) intensity) >> 4), (int) Methods.Truncate(pixel2.G, (int) ((double) (num2 * 1) * (double) intensity) >> 4), (int) Methods.Truncate(pixel2.B, (int) ((double) (num3 * 1) * (double) intensity) >> 4)));
            }
          }
        }
      }
      return directBitmap.Bitmap;
    }

    public static Bitmap GenerateImageNoise(this Bitmap image, int intensity)
    {
      DirectBitmap directBitmap = new DirectBitmap(image);
      Random random = new Random();
      int width = image.Width;
      int height = image.Height;
      for (int x = 0; x < width; ++x)
      {
        for (int y = 0; y < height; ++y)
        {
          Color pixel = directBitmap.GetPixel(x, y);
          if (random.Next(0, 100) < intensity)
          {
            if (random.Next(0, 1) == 0)
            {
              int num = random.Next(0, intensity);
              int red = ((int) pixel.R + (int) pixel.R + num) / 2;
              if (red > (int) byte.MaxValue)
                red = (int) byte.MaxValue;
              int green = ((int) pixel.G + (int) pixel.G + num) / 2;
              if (green > (int) byte.MaxValue)
                green = (int) byte.MaxValue;
              int blue = ((int) pixel.B + (int) pixel.B + num) / 2;
              if (blue > (int) byte.MaxValue)
                blue = (int) byte.MaxValue;
              Color colour = Color.FromArgb((int) byte.MaxValue, red, green, blue);
              directBitmap.SetPixel(x, y, colour);
            }
            else
            {
              int num = random.Next(0, intensity);
              Color colour = Color.FromArgb((int) byte.MaxValue, ((int) pixel.R + (int) pixel.R - num) / 2, ((int) pixel.G + (int) pixel.G - num) / 2, ((int) pixel.B + (int) pixel.B - num) / 2);
              directBitmap.SetPixel(x, y, colour);
            }
          }
        }
      }
      return directBitmap.Bitmap;
    }

    public static string AsciiToHex(this string s)
    {
      StringBuilder stringBuilder = new StringBuilder();
      foreach (char ch in s)
        stringBuilder.Append(Convert.ToInt32(ch).ToString("X"));
      return stringBuilder.ToString();
    }

    public static byte[] ToBytes(this int i)
    {
      return BitConverter.GetBytes(i);
    }

    public static byte[] ToBytes(this uint i)
    {
      return BitConverter.GetBytes(i);
    }

    public static byte[] ToBytes(this byte b)
    {
      return BitConverter.GetBytes((short) b);
    }

    public static byte[] ToBytes(this string s)
    {
      return Encoding.ASCII.GetBytes(s);
    }

    public static byte[] ToBytes(this long l)
    {
      return BitConverter.GetBytes(l);
    }

    public static byte[] ToBytes(this short s)
    {
      return BitConverter.GetBytes(s);
    }

    public static byte[] ToBytes(this ushort s)
    {
      return BitConverter.GetBytes(s);
    }

    //public static byte[] ToBytes(this Image img)
    //{
    //  return (byte[]) new ImageConverter().ConvertTo((object) img, typeof (byte[]));
    //}

    //public static byte[] ToBytes(this Bitmap img)
    //{
    //  return (byte[]) new ImageConverter().ConvertTo((object) img, typeof (byte[]));
    //}

    public static byte[] ToRGBABytes(this Bitmap img)
    {
      List<byte> byteList = new List<byte>();
      for (int y = 0; y < img.Height; ++y)
      {
        for (int x = 0; x < img.Width; ++x)
        {
          Color pixel = img.GetPixel(x, y);
          byteList.Add(pixel.R);
          byteList.Add(pixel.G);
          byteList.Add(pixel.B);
          byteList.Add(pixel.A);
        }
      }
      return byteList.ToArray();
    }

    //public static byte[] CompressImage(this Bitmap bmp, SquishFlags flags)
    //{
    //  byte[] rgbaBytes = bmp.ToRGBABytes();
    //  byte[] numArray = new byte[Squish.Squish.GetStorageRequirements(bmp.Width, bmp.Height, flags)];
    //  int width = bmp.Width;
    //  int height = bmp.Height;
    //  ref byte[] local = ref numArray;
    //  SquishFlags squishFlags = flags;
    //  Squish.Squish.CompressImage(rgbaBytes, width, height, ref local, squishFlags);
    //  return numArray;
    //}

    public static byte ToByte(this int i)
    {
      return BitConverter.GetBytes(i)[0];
    }

    public static byte SetBit(this byte b, int bitIndex, bool value)
    {
      int num = 0;
      if (value)
        num = 1;
      return (byte) ((int) b & ~(1 << bitIndex) | num << bitIndex);
    }

    public static byte[] ReverseBytes(this byte[] bytes)
    {
      Array.Reverse((Array) bytes, 0, bytes.Length);
      return bytes;
    }

    public static byte[] HexStringToByteArray(this string s)
    {
      Dictionary<string, byte> dictionary = new Dictionary<string, byte>();
      for (int index = 0; index <= (int) byte.MaxValue; ++index)
        dictionary.Add(index.ToString("X2"), (byte) index);
      List<byte> byteList = new List<byte>();
      for (int startIndex = 0; startIndex < s.Length; startIndex += 2)
        byteList.Add(dictionary[s.Substring(startIndex, 2)]);
      return byteList.ToArray();
    }

    public static string ByteArrayToHexString(this byte[] array)
    {
      StringBuilder stringBuilder = new StringBuilder(array.Length * 2);
      foreach (byte num in array)
        stringBuilder.AppendFormat("{0:x2}", (object) num);
      return stringBuilder.ToString();
    }

    public static string StringToHexString(this string str)
    {
      return BitConverter.ToString(Encoding.Default.GetBytes(str)).Replace("-", "");
    }

    public static string HexStringToString(this string hexString)
    {
      byte[] bytes = new byte[hexString.Length / 2];
      for (int index = 0; index < bytes.Length; ++index)
        bytes[index] = Convert.ToByte(hexString.Substring(index * 2, 2), 16);
      return Encoding.ASCII.GetString(bytes);
    }

    public static string ReverseHexString(this string s)
    {
      int length1 = s.Length / 2;
      if (length1 % 2 == 0)
      {
        string[] strArray = new string[length1];
        int length2 = s.Length;
        for (int index = 0; index < length1; ++index)
        {
          length2 -= 2;
          strArray[index] = s.Substring(length2, 2);
        }
        s = "";
        foreach (string str in strArray)
          s += str;
      }
      return s;
    }

    public static string F(this string fmt, params object[] args)
    {
      return string.Format(fmt, args);
    }

    public static string ReverseString(this string s)
    {
      char[] charArray = s.ToCharArray();
      Array.Reverse((Array) charArray);
      return new string(charArray);
    }

    public static byte[] ReadBytes(this Stream s, int count)
    {
      if (count < 0)
        throw new ArgumentOutOfRangeException(nameof (count), "Non-negative number required.");
      byte[] buffer = new byte[count];
      if (s.Read(buffer, 0, count) < count)
        throw new EndOfStreamException();
      return buffer;
    }

    public static int Peek(this Stream s)
    {
      byte[] buffer = new byte[1];
      if (s.Read(buffer, 0, 1) == 0)
        return -1;
      Stream stream = s;
      stream.Seek(stream.Position - 1L, SeekOrigin.Begin);
      return (int) buffer[0];
    }

    public static byte ReadUInt8(this Stream s)
    {
      return s.ReadBytes(1)[0];
    }

    public static ushort ReadUInt16(this Stream s)
    {
      return BitConverter.ToUInt16(s.ReadBytes(2), 0);
    }

    public static short ReadInt16(this Stream s)
    {
      return BitConverter.ToInt16(s.ReadBytes(2), 0);
    }

    public static uint ReadUInt32(this Stream s)
    {
      return BitConverter.ToUInt32(s.ReadBytes(4), 0);
    }

    public static int ReadInt32(this Stream s)
    {
      return BitConverter.ToInt32(s.ReadBytes(4), 0);
    }

    public static float ReadFloat(this Stream s)
    {
      return BitConverter.ToSingle(s.ReadBytes(4), 0);
    }

    public static double ReadDouble(this Stream s)
    {
      return BitConverter.ToDouble(s.ReadBytes(8), 0);
    }

    public static string ReadASCII(this Stream s, int length)
    {
      return new string(Encoding.ASCII.GetChars(s.ReadBytes(length)));
    }

    public static string ReadASCIIZ(this Stream s)
    {
      List<byte> byteList = new List<byte>();
      byte[] buffer = new byte[1];
      while (s.Read(buffer, 0, 1) >= 1)
      {
        if (buffer[0] == (byte) 0)
          return new string(Encoding.ASCII.GetChars(byteList.ToArray()));
        byteList.Add(buffer[0]);
      }
      throw new EndOfStreamException();
    }

    public static byte Truncate(byte a, int b)
    {
      if ((int) a + b < 0)
        return 0;
      if ((int) a + b > (int) byte.MaxValue)
        return byte.MaxValue;
      return (byte) ((uint) a + (uint) b);
    }

    public static byte[] FileCheckSum(string fileName)
    {
      if (!File.Exists(fileName))
        return (byte[]) null;
      using (SHA1 shA1 = SHA1.Create())
      {
        using (FileStream fileStream = File.OpenRead(fileName))
          return shA1.ComputeHash((Stream) fileStream);
      }
    }

    public static ushort LittleEndian(ushort val)
    {
      if (BitConverter.IsLittleEndian)
        return val;
      return Methods.conv_endian(val);
    }

    public static uint LittleEndian(uint val)
    {
      if (BitConverter.IsLittleEndian)
        return val;
      return Methods.conv_endian(val);
    }

    public static ushort BigEndian(ushort val)
    {
      if (!BitConverter.IsLittleEndian)
        return val;
      return Methods.conv_endian(val);
    }

    public static uint BigEndian(uint val)
    {
      if (!BitConverter.IsLittleEndian)
        return val;
      return Methods.conv_endian(val);
    }

    private static ushort conv_endian(ushort val)
    {
      return (ushort) ((uint) (ushort) ((uint) (ushort) ((uint) val << 8) & 65280U) | (uint) (ushort) ((int) val >> 8 & (int) byte.MaxValue));
    }

    private static uint conv_endian(uint val)
    {
      return (uint) (((int) val & (int) byte.MaxValue) << 24 | ((int) val & 65280) << 8) | (val & 16711680U) >> 8 | (val & 4278190080U) >> 24;
    }

    public enum DeviceCap
    {
      VERTRES = 10, // 0x0000000A
      DESKTOPVERTRES = 117, // 0x00000075
    }
  }
}
