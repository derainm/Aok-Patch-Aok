﻿// Decompiled with JetBrains decompiler
// Type: SLX_Studio.Global
// Assembly: SLX Studio, Version=1.4.1.0, Culture=neutral, PublicKeyToken=null
// MVID: B1DE9AF1-FC33-4D79-BEAE-2919C4AAE382
// Assembly location: C:\Users\Beleive\Desktop\SLX Studio.exe

using Extension;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Extension
{
  public class Global
  {
    public static bool x86 = false;
    public static float dpi = 1f;
    public static string openFileName = (string) null;
    public static string browserDir = (string) null;
    public static string quickDRSType = "swbg";
    public static string cDir = (string) null;
    public static string psDir = (string) null;
    public static string crDir = (string) null;
    public static string gdDir = (string) null;
    public static string riDir = (string) null;
    public static string cDest = (string) null;
    public static string psDest = (string) null;
    public static string crDest = (string) null;
    public static string fxDest = (string) null;
    public static string riDest = (string) null;
    public static string imageFormat = ".bmp";
    public static string currentFormat = (string) null;
    public static string slxVersion = "SLX 0.5";
    public static bool slxShadowData = false;
    public static string shadowFormat = (string) null;
    public static int cFormat = 1;
    public static int cConvertTo = 0;
    public static int psFormat = 0;
    public static int crFormat = 0;
    public static int gdFormat = 0;
    public static int tbFormat = 0;
    public static int ssFormat = 0;
    public static bool saveGraphicChanges = false;
    public static Color maskColor = Color.FromArgb((int) byte.MaxValue, 0, (int) byte.MaxValue);
    public static Color shadowColor = Color.FromArgb((int) byte.MaxValue, 0, 0);
    public static Color shadowOldColor = Color.FromArgb(91, 0, 91);
    public static Color playerColor = Color.FromArgb(48, 93, 182);
    public static Color oldColor = Color.FromArgb(211, 58, 201);
    public static Color newColor = Color.FromArgb((int) byte.MaxValue, 0, (int) byte.MaxValue);
    public static Color guide1Color = Color.FromArgb(0, (int) byte.MaxValue, (int) byte.MaxValue);
    public static Color guide2Color = Color.FromArgb((int) byte.MaxValue, (int) byte.MaxValue, 0);
    public static Color anchorColor = Color.FromArgb(0, (int) byte.MaxValue, (int) byte.MaxValue);
    public static Color[] shadowColors = new Color[1]
    {
      Color.FromArgb((int) byte.MaxValue, 0, 0)
    };
    public static Color[] playerColors = new Color[1]
    {
      Color.FromArgb(48, 93, 182)
    };
    public static int maskTolerance = 0;
    public static int shadowTolerance = 0;
    public static int playerTolerance = 0;
    public static int playerFixTolerance = 50;
    public static int colorTolerance = 20;
    public static int grayRadius = 50;
    public static bool splitShadowsChecked = false;
    public static bool shadowSLXChecked = true;
    public static bool outlinesChecked = false;
    public static bool outlinesBothChecked = true;
    public static bool autocropChecked = false;
    public static bool subfolderChecked = false;
    public static bool destinationChecked = false;
    public static bool outputChecked = false;
    public static bool omitSubfolderChecked = false;
    public static bool omitDataGraphicsChecked = false;
    public static bool renameOptionChecked = false;
    public static bool deleteOptionChecked = false;
    public static bool paddingFixOptionChecked = false;
    public static bool newSLXOptionChecked = false;
    public static bool playerColorSetChecked = true;
    public static bool playerColor1Checked = false;
    public static bool playerColor2Checked = false;
    public static bool playerColor3Checked = false;
    public static bool playerColor4Checked = false;
    public static bool omitGraysChecked = true;
    public static bool drawFXPosChecked = true;
    public static bool drawFXCVSChecked = false;
    public static bool drawFXAnchorsChecked = false;
    public static bool resizeFixChecked = true;
    public static bool drawFrontChecked = true;
    public static bool drawBehindChecked = false;
    public static bool drawAlwaysFrontChecked = false;
    public static bool drawAlwaysBehindChecked = false;
    public static bool subfolderSLXChecked = false;
    public static bool spriteSheetGuidesChecked = true;
    public static bool maskOn = true;
    public static bool shadowOn = true;
    public static bool shadowFixOn = false;
    public static bool playerOn = true;
    public static bool playerFixOn = true;
    public static bool color1On = true;
    public static bool color2On = false;
    public static bool color3On = false;
    public static bool paletteOn = true;
    public static bool transparentOn = true;
    public static bool anchorsOn = true;
    public static bool resizeOn = false;
    public static bool sameDataImageChecked = true;
    public static bool keepAnchors = false;
    public static bool clearSelected = true;
    public static string dataName = "d";
    public static string damageName = "_dmg";
    public static string shadowSLXFile = (string) null;
    public static string shadowFolder = "shadow";
    public static string shadowSuffix = "sh";
    public static string renameOptionName = (string) null;
    public static string mapFileName = (string) null;
    public static string sheetFileName = (string) null;
    public static string dataImageName = "data";
    public static Decimal paddingSize = new Decimal(4);
    public static Decimal shadowPercent = new Decimal(100);
    public static Decimal playerPercent = new Decimal(100);
    public static Decimal colorPercent = new Decimal(100);
    public static Decimal color2Percent = new Decimal(100);
    public static Decimal color3Percent = new Decimal(100);
    public static Decimal repeat = Decimal.MinusOne;
    public static int xPad = 0;
    public static int yPad = 0;
    public static int colorEdgeIndex = 0;
    public static int color2EdgeIndex = 0;
    public static int color3EdgeIndex = 0;
    public static int playerColorIndex = 0;
    public static int playerColorGroup = 0;
    public static int shadowEdgeIndex = 0;
    public static int playerEdgeIndex = 0;
    public static int fileTypeIndex = 0;
    public static int ditherIndex = 0;
    public static int ditherPercent = 75;
    public static int interpolationIndex = 0;
    public static List<Color> crOldColors = new List<Color>();
    public static List<Color[]> crNewColors = new List<Color[]>();
    public static List<int> crPlayerColorIndex = new List<int>();
    public static List<int> crPlayerColorSet = new List<int>();
    public static List<int> crTolerance = new List<int>();
    public static List<int> crPercentageFrom = new List<int>();
    public static List<int> crEdge = new List<int>();
    public static List<bool> crOmitAlphas = new List<bool>();
    public static List<bool> crOmitGrays = new List<bool>();
    public static int palBoxCount = 11;
    public static int swapBoxCount = 12;
    public static int ddsPixelFormatIndex = 0;
    public static DialogResult DialogResult = DialogResult.None;
    public static Point mouseWheelPos = new Point();
    public static int drsBuildSaveIndex = 1;
    public static int exportSaveIndex = 1;
    public static int terrainSaveIndex = 1;
    public static Color sxpMaskColor = Color.FromArgb((int) byte.MaxValue, 0, (int) byte.MaxValue);
    public static Color sxpShadowColor = Color.FromArgb((int) byte.MaxValue, 0, 0);
    public static Color sxpOutline1Color = Color.FromArgb(0, 0, (int) byte.MaxValue);
    public static Color sxpOutline2Color = Color.FromArgb((int) byte.MaxValue, (int) byte.MaxValue, 0);
    public static int sxpPlayerIndex = 0;
    public static int slpPlayerColorGroup = 0;
    public static int slpPlayerColorStartIndex = 16;
    public static int sxpPalIndex = 1;
    public static bool slpFillBlock = true;
    public static bool slpEmbedPal = false;
    public static bool slpIsTerrain = false;
    public static bool slpIsAoE1 = false;
    public static bool slpIs32bit = false;
    public static bool slpIsAdvanced = false;
    public static bool slp32BitChecked = false;
    public static bool slpTerrainChecked = false;
    public static string sxpPalName = "Standard_Graphics";
    public static bool sxpSplitShadows = false;
    public static bool sxpForcePalette = false;
    public static string slpVersion = "2.0N";
    public static int slpType = 0;
    public static int slpType2 = 2;
    public static string slpComment = string.Format("ADV SLP v{0} SLX Studio", (object) Methods.GetSLXStudioVersion(4));
    public static bool slpCustomComment = false;
    public static bool slpAdvData = false;
    public static bool slpIsDefinitive = false;
    public static bool slpUPData = false;
    public static string slpPlayerColorPalette = "[Current Palette]";
    public static int[] slpPaletteIndices = new int[1];
    public static int[] slpPaletteIDs = new int[1];
    public static byte[] slpUPValues = new byte[4];
    public static bool slpOmitPlayerColors = false;
    public static int terrainBrightestIndex = 0;
    public static int terrainHighlightIndex = 21;
    public static bool slpViewAP = false;
    public static bool slpViewSB = false;
    public static bool slpViewSR = false;
    public static string slpLastSelectionShown = (string) null;
    public static bool sxpViewMask = true;
    public static bool sxpViewShadow = true;
    public static bool sxpViewOutlines = true;
    public static bool slpAutoColorPalette = true;
    public static bool sxpViewTerrain = true;
    public static int slpDecayTime = 0;
    public static int smpDamagePercent = 0;
    public static int smpObjectType = 0;
    public static bool smpDrawOutlines = false;
    public static bool sxpShadowAlphas = false;
    public static int[] smpPaletteIndices = new int[0];
    public static int[] smpPaletteIDs = new int[0];
    public static int tileWidth = 97;
    public static int tileHeight = 49;
    public static int tileMidX = 48;
    public static int tileMidY = 24;
    public static int customTileWidth = 81;
    public static int customTileHeight = 41;
    public static int[] knownTileW = new int[5]
    {
      97,
      65,
      81,
      161,
      321
    };
    public static int[] knownTileH = new int[5]
    {
      49,
      33,
      41,
      81,
      161
    };
    public static bool showAP = false;
    public static bool showSB = false;
    public static bool showSR = false;
    public static string lastSelectionShown = (string) null;
    public static bool showData = true;
    public static bool showShadow = false;
    public static int tilesX = 1;
    public static int tilesY = 1;
    public static int radiusX = 14;
    public static int radiusY = 7;
    public static List<string> graphicFiles = new List<string>();
    public static List<string> originalFiles = new List<string>();
    public static List<string> dataLabels = new List<string>();
    public static List<string> dataFiles = new List<string>();
    public static List<string> originalDataFiles = new List<string>();
    public static List<string> graphicAP = new List<string>();
    public static List<string> shadowAP = new List<string>();
    public static List<string> shadowFiles = new List<string>();
    public static List<string> shadowDataFiles = new List<string>();
    public static List<string> editGraphicFiles = new List<string>();
    public static List<string> editOriginalFiles = new List<string>();
    public static List<string> editDataFiles = new List<string>();
    public static List<string> editOriginalDataFiles = new List<string>();
    public static List<string> editDataLabels = new List<string>();
    public static List<string> editGraphicAP = new List<string>();
    public static bool editFramesStart = false;
    public static bool renameFramesStart = false;
    public static int[] anchorsListX = new int[1];
    public static int[] anchorsListY = new int[1];
    public static int anchorX = 0;
    public static int anchorY = 0;
    public static int shAnchorX = 0;
    public static int shAnchorY = 0;
    public static int imgMaxWidth = 0;
    public static int imgMaxHeight = 0;
    public static int graphicPadX = 0;
    public static int graphicPadY = 0;
    public static double zoomPercent = 100.0;
    public static double previewZoomPercent = 100.0;
    public static int palIndex = 1;
    public static int swapIndex = -1;
    public static bool bit32Checked = false;
    public static string customPalName = (string) null;
    public static string customSwapPalName = (string) null;
    public static bool showPalAlphas = true;
    public static int fxIndex = 0;
    public static string customFXName = (string) null;
    public static int fxDirections = 5;
    public static Color customFXMask = Color.FromArgb((int) byte.MaxValue, (int) byte.MaxValue, 0, (int) byte.MaxValue);
    public static Color customFXShadow = Color.FromArgb((int) byte.MaxValue, (int) byte.MaxValue, 0, 0);
    public static List<Bitmap> customFXImages = new List<Bitmap>();
    public static List<int> customFXAnchorsX = new List<int>();
    public static List<int> customFXAnchorsY = new List<int>();
    public static int[] csvX = new int[1];
    public static int[] csvY = new int[1];
    public static int csvIndex = -1;
    public static string[] iniExceptions134 = new string[104]
    {
      "Palette3Name=",
      "Palette3Path=",
      "Palette4Name=",
      "Palette4Path=",
      "Palette5Name=",
      "Palette5Path=",
      "Palette6Name=",
      "Palette6Path=",
      "Palette7Name=",
      "Palette7Path=",
      "Palette8Name=",
      "Palette8Path=",
      "Palette9Name=",
      "Palette9Path=",
      "Palette10Name=",
      "Palette10Path=",
      "Palette11Name=",
      "Palette11Path=",
      "Palette12Name=",
      "Palette12Path=",
      "Palette13Name=",
      "Palette13Path=",
      "Palette14Name=",
      "Palette14Path=",
      "Palette15Name=",
      "Palette15Path=",
      "Palette16Name=",
      "Palette16Path=",
      "Palette17Name=",
      "Palette17Path=",
      "Palette18ame=",
      "Palette18Path=",
      "Palette19Name=",
      "Palette19Path=",
      "Palette20Name=",
      "Palette20Path=",
      "Palette21Name=",
      "Palette21Path=",
      "Palette22Name=",
      "Palette22Path=",
      "Palette23Name=",
      "Palette23Path=",
      "Palette24Name=",
      "Palette24Path=",
      "Palette25Name=",
      "Palette25Path=",
      "Palette26Name=",
      "Palette26Path=",
      "Palette27Name=",
      "Palette27Path=",
      "Palette28Name=",
      "Palette28Path=",
      "Palette29Name=",
      "Palette29Path=",
      "Palette30Name=",
      "Palette30Path=",
      "Palette31Name=",
      "Palette31Path=",
      "Palette32Name=",
      "Palette32Path=",
      "Palette33Name=",
      "Palette33Path=",
      "Palette34Name=",
      "Palette34Path=",
      "Palette35Name=",
      "Palette35Path=",
      "Palette36Name=",
      "Palette36Path=",
      "Palette37Name=",
      "Palette37Path=",
      "Palette38Name=",
      "Palette38Path=",
      "Palette39Name=",
      "Palette39Path=",
      "Palette40Name=",
      "Palette40Path=",
      "Palette41Name=",
      "Palette41Path=",
      "Palette42Name=",
      "Palette42Path=",
      "Palette43Name=",
      "Palette43Path=",
      "Palette44Name=",
      "Palette44Path=",
      "Palette45Name=",
      "Palette45Path=",
      "SwapPalette1Name=",
      "SwapPalette1Path=",
      "SwapPalette2Name=",
      "SwapPalette2Path=",
      "SwapPalette3Name=",
      "SwapPalette3Path=",
      "SwapPalette4Name=",
      "SwapPalette4Path=",
      "SwapPalette5Name=",
      "SwapPalette5Path=",
      "SwapPalette6Name=",
      "SwapPalette6Path=",
      "SwapPalette7Name=",
      "SwapPalette7Path=",
      "SwapPalette8Name=",
      "SwapPalette8Path=",
      "SwapPalette9Name=",
      "SwapPalette9Path="
    };
    public static string[] iniExceptions136 = new string[3]
    {
      "ExportSaveIndex=",
      "Palette42Name=",
      "Palette44Name="
    };
    public static string tempFolder = (string) null;
    public static bool hideSLXStudio = false;
    public static bool viewerMode = false;
    public static bool highContrastMode = false;
    public static bool closeCancel = false;
    public static bool browseCancel = false;
    public static bool cancelProgress = false;
    public static bool warnOnce = false;
    public static bool listBoxUpdateStart = false;
    public static int listBoxEditModeHeight = 13;
    public static bool qtyDialogCompleted = false;
    public static int qtyDialogValue = 0;
    public static string qtyDialogName = (string) null;
    public static bool tilesDialogCompleted = false;
    public static int tilesDialogRows = 0;
    public static int tilesDialogColumns = 0;
    public static string drsDir;
    public static string quickDRSInput;
    public static string quickDRSOutput;
    public static string dir;
    public static Color[] sxpPal;
    public static Color[] sxpPlayerColorPal;
    public static int sxpDirections;
    public static int sxpFPD;
    public static int slpPaletteID;
    public static string slpAttachSLXFile;
    public static DialogResult exportOptionsResult;
    public static Bitmap gPreview;
    public static Bitmap dataPreview;
    public static Bitmap damagePreview;
    public static Bitmap shadowPreview;
    public static Bitmap shadowDataPreview;
    public static string colorListBoxItem;
    public static Color[] palColors;
    public static Color[] swapColors;
    public static Color[] customPalColors;
    public static Color[] customSwapColors;
    public static string csvName;
  }
}
