﻿// Decompiled with JetBrains decompiler
// Type: GPL_Reader.GplReader
// Assembly: SLX Studio, Version=1.4.1.0, Culture=neutral, PublicKeyToken=null
// MVID: B1DE9AF1-FC33-4D79-BEAE-2919C4AAE382
// Assembly location: C:\Users\Beleive\Desktop\SLX Studio.exe

using Extension;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace Extension
{
  public class GplReader
  {
    public List<Color> palette { get; private set; }

    public GplReader(string fileName)
    {
      FileStream s = File.Open(fileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
      if (s.ReadASCII(12) != "GIMP Palette")
      {
        this.palette = (List<Color>) null;
      }
      else
      {
        long position1 = s.Position;
        try
        {
          this.palette = new List<Color>();
          while (s.Position < s.Length)
          {
            if (s.ReadByte() == 10)
            {
              long position2 = s.Position;
              int count = 0;
              for (int index = s.ReadByte(); index != 10 && s.Position < s.Length; index = s.ReadByte())
                ++count;
              s.Position = position2;
              string str = Regex.Replace(Regex.Replace(Encoding.Default.GetString(s.ReadBytes(count)), "\\s\\s+", " "), "\\t", " ");
              str.Trim();
              string[] strArray = str.Split(new string[1]
              {
                " "
              }, StringSplitOptions.RemoveEmptyEntries);
              if (strArray.Length >= 3 && strArray[0].IsNumeric() && (strArray[1].IsNumeric() && strArray[2].IsNumeric()))
              {
                int red = strArray[0].ToInt();
                int num1 = strArray[1].ToInt();
                int num2 = strArray[2].ToInt();
                int green = num1;
                int blue = num2;
                this.palette.Add(Color.FromArgb(red, green, blue));
              }
            }
          }
        }
        finally
        {
          s.Close();
        }
      }
    }

    public Color[] PaletteColors()
    {
      if (this.palette != null)
        return this.palette.ToArray();
      return (Color[]) null;
    }
  }
}
